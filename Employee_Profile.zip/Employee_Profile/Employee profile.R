#Writing R script to unzip and display employee data

#Load necessary libraries.
library(readr)

#unzip the folder
unzip("Employee profile.zip")

#Load and display the CSV file

employee_dtails <- read_csv("employee_details.csv")
print(employee_details)
